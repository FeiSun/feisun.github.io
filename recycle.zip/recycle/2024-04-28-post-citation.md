---
layout: post
title: a post that can be cited
date: 2024-04-28 15:06:00
description: this is what a post that can be cited looks like
tags: formatting citation
categories: sample-posts
citation: true
---

This is an example post that can be cited. The content of the post ends here, while the citation information is automatically provided below. The only thing needed is for you to set the `citation` key in the front matter to `true`.
